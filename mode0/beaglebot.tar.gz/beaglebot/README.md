beaglebot
=========

This repository contains all my code for Beaglebot, a simple robot built on the Beagleboard.org Beaglebone computer (http://beagleboard.org/Products/BeagleBone).  Website for the Beaglebot is currently located at http://nathanielrlewis.com/?page_id=84

encoders
--------

This directory contains a driver and API for the Enhanced Quadrature Encoder Pulse (eQEP) decoder found on the AM33xx series TI SoCs.  Designed for the Beaglebone and Beaglebone Black.  A C++ and Python API are provided.

hcsr04-demo
-----------

This directory contains an example of using the beaglebone with an HC-SR04 sonar.

